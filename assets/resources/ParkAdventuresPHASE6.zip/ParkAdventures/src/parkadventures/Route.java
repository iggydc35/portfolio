/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parkadventures;

import java.util.ArrayList;

/**
 *
 * @author metudoreanu
 */
public class Route {
    private String name;
    private String bestTime;
    private ArrayList<Waypoint> sequence = new ArrayList<>(); 
    
    @Override
    public String toString(){
        String tmp = name;
        tmp = tmp + " " + getBestTime();
        double d = computeTotalLength();
        d = Math.round(d * 100) / 100.0; //this is to keep only two digits after the decimal point
        tmp = tmp + " " + d + " mi";
        return tmp;
    }
   
    
    public int getSizeSequence(){
        return sequence.size();
    }
    
    public Waypoint getWaypoint(int idx){
        return sequence.get(idx);
    }
    
    public int getIndex(Waypoint w){
        return sequence.indexOf(w);
    }
    
    public void addWaypoint(int idx, Waypoint additional){ //insert an element at position idx
        sequence.add(idx, additional);
    }
    
    public void addWaypointAtEnd(Waypoint additional){
        sequence.add(additional);
    }
    
    public void removeWaypoint(int idx){ //removes the waypoint at a given position
        sequence.remove(idx);
    }
    
    public void removeWaypoint(Waypoint whichOne){ //removes the waypoint regardless of position
        sequence.remove(whichOne);
    }
    
    public boolean hasWaypoint(Waypoint w){
        if(sequence.contains(w))
            return true;
        else
            return false;
    }
    
    public double computeTotalLength(){
        if(sequence.size() < 2)
            return 0; //not enough points to travel
        
        double tmpLength = 0;
        for(int i = 1; i < sequence.size(); i++){
            //compute distance between two points
            Waypoint prev, next;
            double dist;
            prev = sequence.get(i-1);
            next = sequence.get(i);
            dist = Math.sqrt((prev.getEastDistance() - next.getEastDistance()) * (prev.getEastDistance() - next.getEastDistance()) +
                    (prev.getNorthDistance() - next.getNorthDistance()) * (prev.getNorthDistance() - next.getNorthDistance()));
            tmpLength = tmpLength + dist; //add the distance between these two points to tmp
        }
        return tmpLength;    
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBestTime() {
        return bestTime;
    }

    public void setBestTime(String bestTime) {
        this.bestTime = bestTime;
    }
    
    
}
