/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parkadventures;

/**
 *
 * @author metudoreanu
 */
public class Waypoint {
    private String name;
    private double eastDistance;
    private double northDistance;
    private String activities;
    private String avoid;
    
    @Override
    public String toString(){
        String tmp = "* ";
        //check if this waypoint is being used by a route
        for(int i = 0; i < ParkAdventures.routes.size(); i++){
            Route r;
            r = ParkAdventures.routes.get(i);
            if(r.hasWaypoint(this)){ //is 'this' object inside route r
                tmp = "";
                break; //this waypoint is being used, so I can stop searching
            }
        }
        tmp = tmp + name + ": (" + eastDistance + ", " + northDistance + ")";
        tmp = tmp + " " + activities;
        tmp = tmp + ", " + avoid;
        return tmp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getEastDistance() {
        return eastDistance;
    }

    public void setEastDistance(double eastDistance) {
        this.eastDistance = eastDistance;
    }

    public double getNorthDistance() {
        return northDistance;
    }

    public void setNorthDistance(double northDistance) {
        this.northDistance = northDistance;
    }

    public String getActivities() {
        return activities;
    }

    public void setActivities(String activities) {
        this.activities = activities;
    }

    public String getAvoid() {
        return avoid;
    }

    public void setAvoid(String avoid) {
        this.avoid = avoid;
    }    
}
